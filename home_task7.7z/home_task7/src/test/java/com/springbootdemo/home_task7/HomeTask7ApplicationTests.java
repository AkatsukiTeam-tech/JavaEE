package com.springbootdemo.home_task7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeTask7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
