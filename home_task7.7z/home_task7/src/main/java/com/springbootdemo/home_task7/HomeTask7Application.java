package com.springbootdemo.home_task7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeTask7Application {

	public static void main(String[] args) {
		SpringApplication.run(HomeTask7Application.class, args);
	}

}
