package com.springbootdemo.home_task7.controllers;

import com.springbootdemo.home_task7.entities.*;
import com.springbootdemo.home_task7.services.ItemService;
import com.springbootdemo.home_task7.services.UserService;
import javassist.ClassPath;
import net.bytebuddy.implementation.bytecode.constant.MethodConstant;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class HomeController {
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private ItemService itemService;

    @Autowired
    private UserService userService;

    @Value("${file.avatar.viewPath}")
    private String viewPath;

    @Value("${file.avatar.uploadPath}")
    private String uploadPath;

    @Value("${file.avatar.defaultPicture}")
    private String defaultPicture;

    @Value("${file.picture.viewItemPicture}")
    private String viewItemPicture;

    @Value("${file.picture.uploadItemPicture}")
    private String uploadItemPicture;

    static double item_price;
    static int item_amount;
    @GetMapping(value = "/")
    public String index(Model model){
        List<ShopItems> items = itemService.findAllSortedByInTop();
        model.addAttribute("items", items);

        List<Countries> countries = itemService.getAllCountries();
        model.addAttribute("countries", countries);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        model.addAttribute("user", getUserData());
        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);

        return "index";
    }

    @GetMapping(value = "/detailsItem")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MODER')")
    public String det_item(Model model, @RequestParam(name = "id") Long id){
        ShopItems item = itemService.getItem(id);
        model.addAttribute("item", item);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        categories = categories.stream().filter(c -> !item.getCategories().contains(c)).collect(Collectors.toList());
        model.addAttribute("categories", categories);

        List<Pictures> pictures = itemService.getAllPictures();
        pictures = pictures.stream().filter(p -> p.getItems().getId().equals(item.getId())).collect(Collectors.toList());
        model.addAttribute("pictures", pictures);

        model.addAttribute("user", getUserData());

        return "detailsItem";
    }

    @GetMapping(value = "/detailsUser")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String det_user(Model model, @RequestParam(name = "id") Long id){
        Users user = userService.getUser(id);
        model.addAttribute("user_edit", user);

        List<Roles> roles = userService.getAllRoles();
        roles = roles.stream().filter(c -> !user.getRoles().contains(c)).collect(Collectors.toList());

        model.addAttribute("roles", roles);

        model.addAttribute("user", getUserData());

        return "detailsUser";
    }

    @PostMapping(value = "/addItem")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MODER')")
    public String addItem(@RequestParam(name = "brands_id") Long id,
                          @RequestParam(name = "name") String name,
                          @RequestParam(name = "desc") String desc,
                          @RequestParam(name = "price") int price,
                          @RequestParam(name = "stars") int stars,
                          @RequestParam(name = "top") boolean top,
                          @RequestParam(name = "sm_pic_url") String sm_pic_url,
                          @RequestParam(name = "lr_pic_url") String lr_pic_url){

        Brands brands = itemService.getBrands(id);

        if (brands != null){

            ShopItems item = new ShopItems();
            item.setName(name);
            item.setDesc(desc);
            item.setPrice(price);
            item.setStars(stars);
            item.setInTopPage(top);
            item.setSmallPic(sm_pic_url);
            item.setLargePic(lr_pic_url);
            item.setBrands(brands);

            itemService.addItem(item);

        }

        return "redirect:/admin";
    }

    @PostMapping(value = "/addRole")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String addRole(@RequestParam(name = "name") String name,
                          @RequestParam(name = "desc") String desc){


        Roles role = new Roles();
        role.setRole(name);
        role.setDesc(desc);

        userService.addRoles(role);

        return "redirect:/admin";
    }

    @PostMapping(value = "/regis")
    public String regis(Model model, @RequestParam(name = "full_name") String name,
                          @RequestParam(name = "email") String email,
                          @RequestParam(name = "password") String password,
                          @RequestParam(name = "re_password") String re_pass){

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        model.addAttribute("user", getUserData());

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        Users user = userService.getUserByEmail(email);

        if (user == null) {
            if (password.equals(re_pass)) {
                user = new Users();
                user.setFull_name(name);
                user.setEmail(email);
                user.setPassword(passwordEncoder.encode(password));
                userService.addUser(user);
                return "login";
            } else {
                model.addAttribute("mess", "Wrong Retype Password");
                return "regis";
            }
        }else {
            model.addAttribute("mess", "This email is already registered");
            return  "regis";
        }
    }

    @PostMapping(value = "/addUser")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String addUser(Model model, @RequestParam(name = "full_name") String name,
                          @RequestParam(name = "email") String email,
                          @RequestParam(name = "password") String password,
                          @RequestParam(name = "re_password") String re_pass){

        List<ShopItems> items = itemService.getAllItems();
        model.addAttribute("items", items);

        List<Countries> countries = itemService.getAllCountries();
        model.addAttribute("countries", countries);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        List<Users> users = userService.getAllUser();
        model.addAttribute("users", users);

        List<Roles> roles = userService.getAllRoles();
        model.addAttribute("roles", roles);

        model.addAttribute("user", getUserData());

        Users user = userService.getUserByEmail(email);

        if (user == null) {
            if (password.equals(re_pass)) {
                user = new Users();
                user.setFull_name(name);
                user.setEmail(email);
                user.setPassword(passwordEncoder.encode(password));
                userService.addUser(user);
                return "redirect:/admin";
            } else {
                model.addAttribute("mess", "Wrong Retype Password");
                return "admin";
            }
        }else {
            model.addAttribute("mess", "This email is already registered");
            return "admin";
        }
    }

    @GetMapping(value = "/delete/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String delete(Model model, @PathVariable (name = "id") Long id){
        itemService.deleteItem(id);
        model.addAttribute("user", getUserData());
        return "redirect:/admin";
    }

    @GetMapping(value = "/details/{id}")
    public String details(Model model, @PathVariable(name = "id") Long id){
        ShopItems items = itemService.getItem(id);
        model.addAttribute("item", items);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);


        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Pictures> pictures = itemService.getAllPictures();
        pictures = pictures.stream().filter(p -> p.getItems().getId().equals(items.getId())).collect(Collectors.toList());
        model.addAttribute("pictures", pictures);

        List<Comments> comments = userService.getAllComments();
        ArrayList<Comments> list = new ArrayList<>();
        for (Comments c : comments){
            if (c.getItem().getId() == id){
                list.add(c);
            }
        }
        model.addAttribute("comments", list);
        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);
        model.addAttribute("user", getUserData());
        return "details";
    }

    @PostMapping("/saveItem")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MODER')")
    public String save(@RequestParam(name = "id") Long id,
                       @RequestParam(name = "brands_id") Long b_id,
                       @RequestParam(name = "name") String name,
                       @RequestParam(name = "desc") String desc,
                       @RequestParam(name = "price") int price,
                       @RequestParam(name = "stars") int stars,
                       @RequestParam(name = "top") boolean top,
                       @RequestParam(name = "sm_pic_url") String sm_pic_url,
                       @RequestParam(name = "lr_pic_url") String lr_pic_url){

        Brands brands = itemService.getBrands(b_id);

        if (brands != null){
            ShopItems items = itemService.getItem(id);
            items.setName(name);
            items.setDesc(desc);
            items.setPrice(price);
            items.setStars(stars);
            items.setInTopPage(top);
            items.setSmallPic(sm_pic_url);
            items.setLargePic(lr_pic_url);
            items.setBrands(brands);
            itemService.saveItem(items);
        }

        return "redirect:/admin";
    }

    @PostMapping(value = "/sorted")
    public String sorted(Model model,
                         @RequestParam(name = "name", defaultValue = "") String name,
                         @RequestParam(name = "brand_id", defaultValue = "0") Long id,
                         @RequestParam(name = "price_from", defaultValue = "0") double from,
                         @RequestParam(name = "price_to", defaultValue = "99999") double to,
                         @RequestParam(name = "ascending", defaultValue = "") String sort){
        List<ShopItems> items = null;
        Brands brand = itemService.getBrands(id);
        List<Brands> brands = itemService.getAllBrands();

        List<Categories> categories = itemService.getAllCategories();

        model.addAttribute("categories", categories);

        model.addAttribute("user", getUserData());
        if (brands != null){
            if (name.equals("")){
                if (sort.equals("ascending")){
                    items = itemService.findAllByBrandsOrderByPriceAsc(brand);
                }
                else {
                    items = itemService.findAllByBrandsOrderByPriceDesc(brand);
                }
            }
            else {
                if (sort.equals("ascending")) {
                    items = itemService.findAllByBrandsAndNameOrderByPriceAsc(from, to, name, brand);
                }
                else {
                    items = itemService.findAllByBrandsAndNameOrderByPriceDesc(from, to, name, brand);
                }
            }
        }
        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);
        model.addAttribute("items", items);
        model.addAttribute("brands", brands);
        return "search";
    }

    @GetMapping(value = "/admin")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MODER')")
    public String admin(Model model){
        List<ShopItems> items = itemService.getAllItems();
        model.addAttribute("items", items);

        List<Countries> countries = itemService.getAllCountries();
        model.addAttribute("countries", countries);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        List<Users> users = userService.getAllUser();
        model.addAttribute("users", users);

        List<Roles> roles = userService.getAllRoles();
        model.addAttribute("roles", roles);

        List<Busket> buskets = itemService.getAllBusket();
        model.addAttribute("basket", buskets);

        model.addAttribute("user", getUserData());

        return "admin";
    }

    @PostMapping(value = "/addBrand")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String addBrand(@RequestParam(name = "name") String name,
                           @RequestParam(name = "country_id") Long id){

        Countries countries = itemService.getCountry(id);
        if (countries != null){

            itemService.addBrands(new Brands(null, name, countries));

        }
        return "redirect:/admin";
    }

    @GetMapping(value = "/detailsBrand")
    public String detailsBrand(Model model, @RequestParam(name = "id") Long id){

        Brands brand = itemService.getBrands(id);

        if (brand != null){
            List<ShopItems> items = itemService.findAllByBrandsOrderByPriceAsc(brand);
            model.addAttribute("user", getUserData());

            model.addAttribute("items", items);
        }

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        model.addAttribute("user", getUserData());
        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);
        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);
        return "search";
    }

    @PostMapping(value = "/addCountry")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String addCountry(@RequestParam(name = "name") String name,
                             @RequestParam(name = "code") String code){

        itemService.addCountry(new Countries(null, name, code));
        return "redirect:/admin";
    }

    @PostMapping(value = "/addCategory")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String addCategory(@RequestParam(name = "name") String name,
                             @RequestParam(name = "logo") String logo){

        itemService.addCategories(new Categories(null, name, logo));
        return "redirect:/admin";
    }

    @PostMapping(value = "/editCountry")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String editCountry(@RequestParam(name = "id") Long id,
                              @RequestParam(name = "name") String name,
                              @RequestParam(name = "code") String code){

        Countries countries = itemService.getCountry(id);
        if (countries != null) {
            countries.setName(name);
            countries.setCode(code);
            itemService.saveCountry(countries);
        }
        return "redirect:/admin";
    }

    @PostMapping(value = "/editBrand")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String editBrands(@RequestParam(name = "id") Long id,
                              @RequestParam(name = "name") String name,
                              @RequestParam(name = "country_id") Long c_id){

        Brands brands = itemService.getBrands(id);
        if (brands != null) {
            Countries countries = itemService.getCountry(c_id);
            if (countries != null){
                brands.setName(name);
                brands.setCountry(countries);
                itemService.saveBrands(brands);
            }
        }
        return "redirect:/admin";
    }

    @PostMapping(value = "/editCategory")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String editCategory(@RequestParam(name = "id") Long id,
                              @RequestParam(name = "name") String name,
                              @RequestParam(name = "logo") String logo){

        Categories categories = itemService.getCategories(id);
        if (categories != null) {
            categories.setName(name);
            categories.setLogo(logo);
            itemService.saveCategories(categories);
        }
        return "redirect:/admin";
    }

    @PostMapping(value = "/editUser")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String editUser(@RequestParam(name = "id") Long id,
                           @RequestParam(name = "full_name") String name,
                           @RequestParam(name = "email") String email,
                           @RequestParam(name = "password") String password){

        Users user = userService.getUser(id);
        if (user != null) {
            user.setFull_name(name);
            user.setEmail(email);
            user.setPassword(passwordEncoder.encode(password));
            userService.SaveUser(user);
        }
        return "redirect:/admin";
    }

    @PostMapping(value = "/editRole")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String editRole(@RequestParam(name = "id") Long id,
                           @RequestParam(name = "name") String name,
                           @RequestParam(name = "desc") String desc){

        Roles role = userService.getRoles(id);
        if (role != null) {
            role.setRole(name);
            role.setDesc(desc);
            userService.saveRoles(role);
        }
        return "redirect:/admin";
    }

    @PostMapping(value = "/editProfile")
    public String editProfile(Model model,
                              @RequestParam(name = "id") Long id,
                              @RequestParam(name = "full_name") String name,
                              @RequestParam(name = "email") String email){

        Users user = userService.getUser(id);
        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        model.addAttribute("user", getUserData());

        if (user != null) {
            user.setFull_name(name);
            user.setEmail(email);
            userService.SaveUser(user);
            model.addAttribute("success_prof", "Successfully");
        }
        return "profile";
    }


    @PostMapping(value = "/editPassword")
    public String editPassword(Model model, @RequestParam(name = "id") Long id,
                               @RequestParam(name = "password") String password,
                               @RequestParam(name = "new_pass") String new_pass,
                               @RequestParam(name = "re_pass") String re_pass){

        Users user = userService.getUser(id);
        model.addAttribute("user", getUserData());

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        if (user != null) {

            if (passwordEncoder.matches(password, user.getPassword())){

                if (new_pass.equals(re_pass)) {

                    user.setPassword(passwordEncoder.encode(new_pass));
                    userService.SaveUser(user);
                    model.addAttribute("success_pass", "Successfully");

                }else {
                    model.addAttribute("mess", "Wrong Retype Password");
                }
            }
            else {
                model.addAttribute("mess", "Wrong Old Password");
            }
        }
        return "profile";
    }

    @PostMapping(value = "/editAvatar")
    @PreAuthorize("isAuthenticated()")
    public String editAvatar(Model model,
                             @RequestParam(name = "id") Long id,
                             @RequestParam(name = "picture") MultipartFile file){

        Users user = userService.getUser(id);

        long size = (long) (file.getSize() * 0.00000095367432);
        long maxSize = 1;

        if (size <= maxSize){

            if (file.getContentType().equals("image/jpeg") || file.getContentType().equals("image/png")) {

                try {
                    String picture = DigestUtils.sha1Hex("avatar_" + user.getEmail() + "_!Picture");
                    byte[] bytes = file.getBytes();
                    Path path = Paths.get(uploadPath + picture + ".jpg");
                    Files.write(path, bytes);

                    if (user != null) {
                        user.setPicture(picture);
                        userService.SaveUser(user);
                        model.addAttribute("success_avatar", "Successfully");
                    }
                } catch (Exception e) {
                    model.addAttribute("file_error", "The file size exceeds 1 MB, please choose a different file");
                    return "profile";
                }
            }
        }
        else {
            model.addAttribute("file_error", "The file size exceeds 1 MB, please choose a different file");
            return "profile";
        }


        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        model.addAttribute("user", getUserData());

        return "profile";
    }

    @GetMapping(value = "/viewAvatar/{url}", produces = {MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_PNG_VALUE})
    @PreAuthorize("isAuthenticated()")
    public @ResponseBody byte[] viewAvatar(@PathVariable(name = "url") String url) throws IOException {

        String picture = viewPath+defaultPicture;
        if (url != null){
            picture = viewPath+url+".jpg";
        }

        InputStream in;

        Users users = getUserData();
        if (users.getPicture() == null){
            ClassPathResource resource = new ClassPathResource(viewPath+defaultPicture);
            in = resource.getInputStream();
        }
        else {
            ClassPathResource resource = new ClassPathResource(picture);
            in = resource.getInputStream();
        }

        return IOUtils.toByteArray(in);

    }

    @GetMapping(value = "/viewPicture/{url}", produces = {MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_PNG_VALUE})
    public @ResponseBody byte[] viewPicture(@PathVariable(name = "url") String url) throws IOException {

        String picture = viewItemPicture;
        if (url != null){
            picture = viewItemPicture + url + ".jpg";
        }

        InputStream in;

        ClassPathResource resource = new ClassPathResource(picture);
        in = resource.getInputStream();

        return IOUtils.toByteArray(in);

    }

    @PostMapping(value = "/assignPictures")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MODER')")
    public String assign_pic(@RequestParam(name = "item_id") Long itemId,
                             @RequestParam(name = "picture") MultipartFile file){

        ShopItems items = itemService.getItem(itemId);
        long size = (long) (file.getSize() * 0.00000095367432);
        long maxSize = 1;

        if(size <= maxSize){
            if (file.getContentType().equals("image/jpeg") || file.getContentType().equals("image/png")){
                try{
                    String picture = DigestUtils.sha1Hex("picture_" + file.getOriginalFilename() + "_!Name");
                    byte[] bytes = file.getBytes();
                    Path path = Paths.get(uploadItemPicture + picture + ".jpg");
                    Files.write(path, bytes);

                    if (items != null){
                        Pictures pictures = new Pictures();
                        pictures.setUrl(picture);
                        pictures.setItems(items);
                        pictures.setDate(new Date());
                        itemService.addPictures(pictures);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }

        if (items != null){

        }
        return "redirect:/detailsItem?id=" + itemId;
    }

    @PostMapping(value = "/ReAssignPictures")
    public String re_assign_pic(@RequestParam(name = "picture_id") Long id,
                                @RequestParam(name = "item_id") Long itemId){

        Pictures picture = itemService.getPictures(id);
        if (picture != null){
            itemService.deletePictures(id);
        }
        return "redirect:/detailsItem?id=" + itemId;
    }

    @PostMapping(value = "/assignCategory")
    public String assign_cat(@RequestParam(name = "item_id") Long itemId,
                             @RequestParam(name = "category_id") Long catId){

        Categories categories = itemService.getCategories(catId);
        if (categories != null){

            ShopItems items = itemService.getItem(itemId);
            if (items != null){

                List<Categories> categoriesList = items.getCategories();

                if (categoriesList == null){

                    categoriesList = new ArrayList<>();

                }
                categoriesList.add(categories);
                itemService.saveItem(items);

            }

        }
        return "redirect:/detailsItem?id=" + itemId;
    }

    @PostMapping(value = "/ReAssignCategory")
    public String re_assign_cat(@RequestParam(name = "item_id") Long itemId,
                                @RequestParam(name = "category_id") Long catId){

        Categories categories = itemService.getCategories(catId);
        if (categories != null){

            ShopItems items = itemService.getItem(itemId);
            if (items != null){

                List<Categories> categoriesList = items.getCategories();

                if (categoriesList == null){

                    categoriesList = new ArrayList<>();

                }
                categoriesList.remove(categories);
                itemService.saveItem(items);
            }

        }
        return "redirect:/detailsItem?id=" + itemId;
    }

    @PostMapping(value = "/assignRoles")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String assign_role(@RequestParam(name = "user_id") Long userId,
                              @RequestParam(name = "role_id") Long roleId){

        Roles roles = userService.getRoles(roleId);
        if (roles != null){

            Users users = userService.getUser(userId);
            if (users != null){

                List<Roles> rolesList = users.getRoles();

                if (rolesList == null){

                    rolesList = new ArrayList<>();

                }
                rolesList.add(roles);
                userService.SaveUser(users);

            }

        }
        return "redirect:/detailsUser?id=" + userId;
    }

    @PostMapping(value = "/ReAssignRoles")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String re_assign_role(@RequestParam(name = "user_id") Long userId,
                                 @RequestParam(name = "role_id") Long roleId){

        Roles roles = userService.getRoles(roleId);
        if (roles != null){

            Users users = userService.getUser(userId);
            if (users != null){

                List<Roles> rolesList = users.getRoles();

                if (rolesList == null){

                    rolesList = new ArrayList<>();

                }
                rolesList.remove(roles);
                userService.SaveUser(users);

            }

        }
        return "redirect:/detailsUser?id=" + userId;
    }

    @GetMapping(value = "/403")
    public String access_denied(Model model){
        model.addAttribute("user", getUserData());

        return "403";

    }

    @GetMapping(value = "/login")
    public String login(Model model){
        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);
        model.addAttribute("user", getUserData());
        model.addAttribute("user", getUserData());

        return "login";
    }

    @GetMapping(value = "/regis")
    public String registration(Model model){
        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);
        model.addAttribute("user", getUserData());
        return "regis";
    }

    @GetMapping(value = "/profile")
    @PreAuthorize("isAuthenticated()")
    public String profile(Model model){
        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);
        model.addAttribute("user", getUserData());
        return "profile";
    }

    @GetMapping (value = "/addToBasket")
    public String addToBusket(@RequestParam(name = "item_id") Long id,
                              @RequestParam(name = "method") String method,
                              Model model, HttpServletRequest request){

        HttpSession session = request.getSession();
        double sum = 0;
        int amount = 0;
        List<Busket> b_items = (List<Busket>) session.getAttribute("basket");
        if (b_items == null){
            b_items = new ArrayList<>();
            ShopItems items = itemService.getItem(id);
            Busket busket = new Busket(id, 1, items);
            b_items.add(busket);
        }
        else{
            Busket busket = null;
            for (Busket b : b_items){
                if (b.getId().equals(id)){
                    busket = b;
                    break;
                }
            }
            if (busket != null){
                if (method.equals("plus")){
                    busket.setAmount(busket.getAmount() + 1);
                }
                else if (method.equals("minus")){
                    busket.setAmount(busket.getAmount() - 1);
                    if(busket.getAmount() == 0){
                        b_items.remove(busket);
                    }
                }
                else if(method.equals("clear")){
                    sum = 0;
                    amount = 0;
                    b_items.clear();
                }
            }
            else {
                ShopItems items = itemService.getItem(id);
                Busket busket1 = new Busket(id, 1, items);
                busket = busket1;
                b_items.add(busket);
            }
        }

        for (Busket b : b_items){
            sum += b.getItems().getPrice() * b.getAmount();
            amount += b.getAmount();
        }
        List<Busket> busketList = b_items;
        List<ShopItems> items = itemService.findAllSortedByInTop();
        model.addAttribute("items", items);

        List<Countries> countries = itemService.getAllCountries();
        model.addAttribute("countries", countries);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);

        if (busketList != null){
            session.setAttribute("basket", busketList);
        }
        else {
            session.setAttribute("basket", null);
        }
        item_price = sum;
        item_amount = amount;
        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);
        model.addAttribute("user", getUserData());

        return "redirect:/";
    }

    @GetMapping(value = "/paymentPage")
    public String payment(Model model){
        List<ShopItems> items = itemService.findAllSortedByInTop();
        model.addAttribute("items", items);

        List<Countries> countries = itemService.getAllCountries();
        model.addAttribute("countries", countries);

        List<Brands> brands = itemService.getAllBrands();
        model.addAttribute("brands", brands);

        List<Categories> categories = itemService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("sum", item_price);
        model.addAttribute("amount", item_amount);
        model.addAttribute("user", getUserData());

        return "payment";
    }

    @PostMapping(value = "/checkIn")
    public String checkIn(HttpServletRequest request,@RequestParam(name = "full_name")String full_name,
                          @RequestParam(name = "card_number")String card_number,
                          @RequestParam(name = "expiration")String expiration,
                          @RequestParam(name = "cvv")String cvv){
        HttpSession session = request.getSession();
        List<Busket> buskets = (List<Busket>) session.getAttribute("basket");
        ShopItems items;
        String item_name = "";
        double sum = 0;

        for (Busket b : buskets) {
            items = itemService.getItem(b.getItems().getId());
            sum = sum + items.getPrice() * b.getAmount();
            item_name += items.getName()+ "*" + b.getAmount() + "\n";
        }

        Busket busket = new Busket();
        busket.setUser_name(full_name);
        busket.setPrice(sum);
        busket.setItem_name(item_name);
        java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
        busket.setDate(date);
        itemService.addBusket(busket);
        buskets.clear();
        item_amount = 0;
        item_price = 0;
        session.setAttribute("basket" , buskets);
        return "redirect:/";
    }

    @PostMapping(value = "/addComment")
    public String addComment(@RequestParam(name = "comment") String comment,
                             @RequestParam(name = "item_id") Long item_id,
                             @RequestParam(name = "user_id") Long user_id){

        ShopItems item = itemService.getItem(item_id);
        Users user = userService.getUser(user_id);
        if (item != null && user != null){

            java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
            userService.addComment(new Comments(null, comment, date, item, user));

        }

        return "redirect:/details/"+item_id;
    }

    @PostMapping(value = "/editComment")
    public String editComment(@RequestParam(name = "comment") String comment,
                              @RequestParam(name = "id") Long id,
                              @RequestParam(name = "item_id") Long item_id){

        Comments comments = userService.getComment(id);
        if (comments != null){
            comments.setComment(comment);
            java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
            comments.setDate(date);
            userService.saveComment(comments);

        }

        return "redirect:/details/"+item_id;
    }

    @PostMapping(value = "/deleteComment")
    public String deleteComment(@RequestParam(name = "id") Long id,
                              @RequestParam(name = "item_id") Long item_id){

        Comments comments = userService.getComment(id);
        if (comments != null){
            userService.deleteComment(id);

        }

        return "redirect:/details/"+item_id;
    }



    private Users getUserData(){

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (!(authentication instanceof AnonymousAuthenticationToken)){
            User secUser = (User) authentication.getPrincipal();
            Users myUser = userService.getUserByEmail(secUser.getUsername());
            return myUser;
        }

        return null;

    }
}
